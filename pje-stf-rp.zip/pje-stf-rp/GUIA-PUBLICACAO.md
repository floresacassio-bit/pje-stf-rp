# PJe STF-RP – Guia de publicação (tudo gratuito)

Tempo estimado: 30 a 40 minutos. Você usa só o navegador, sem instalar nada.
Os nomes dos botões da Cloudflare e do Discord podem mudar um pouco; se algo estiver com outro nome, procure o equivalente.

## 1. Colocar o código no GitHub

1. No GitHub, clique em **New repository**. Nome sugerido: `pje-stf-rp`. Marque **Private**. Crie.
2. Na página do repositório, clique em **uploading an existing file**.
3. Descompacte o `pje-stf-rp.zip` no seu computador e arraste **o conteúdo** da pasta (`src`, `public`, `package.json`, `schema.sql`, `wrangler.toml` etc.) para o GitHub. Não suba `node_modules` nem `.dev.vars` (o zip já não os inclui).
4. Clique em **Commit changes**.

## 2. Criar o banco de dados (Cloudflare D1)

1. Na Cloudflare: **Storage & Databases → D1 → Create database**. Nome: `pje-stf-rp`.
2. Copie o **Database ID** (um código longo) que aparece na página do banco.
3. Abra a aba **Console** do banco, cole **todo** o conteúdo do arquivo `schema.sql` e execute. Isso cria as tabelas.
4. No GitHub, abra o arquivo `wrangler.toml`, clique no lápis (editar) e troque `COLE_AQUI_O_ID_DO_BANCO` pelo ID copiado. Faça o commit.

## 3. Publicar o site

1. Na Cloudflare: **Workers & Pages → Create → Import a repository** (ou "Connect to Git"). Autorize o GitHub e escolha `pje-stf-rp`.
2. Nome do projeto: `pje-stf-rp`. Deixe o comando de build vazio e o de deploy como `npx wrangler deploy`.
3. Conclua. Ao terminar, a Cloudflare mostra o endereço do site, algo como `https://pje-stf-rp.SEU-USUARIO.workers.dev`. **Anote esse endereço.**

## 4. Criar o aplicativo no Discord

1. Em discord.com/developers/applications: **New Application** (nome: PJe STF-RP).
2. Em **OAuth2**: copie o **Client ID** e gere/copie o **Client Secret**.
3. Ainda em OAuth2, em **Redirects**, adicione exatamente:
   `https://SEU-ENDERECO.workers.dev/auth/callback` e salve.
4. No Discord (aplicativo), ative **Modo desenvolvedor** (Configurações → Avançado). Depois:
   - clique com o botão direito no **servidor do RP → Copiar ID do servidor** (`DISCORD_GUILD_ID`);
   - em Configurações do servidor → Cargos, botão direito no cargo **OAB → Copiar ID do cargo** (`DISCORD_OAB_ROLE_ID`);
   - botão direito no seu perfil → **Copiar ID do usuário** (vai para `ADMIN_IDS`; vários IDs separados por vírgula).

## 5. Configurar o site

**Dados não secretos:** no GitHub, edite o `wrangler.toml` e preencha:

```
DISCORD_CLIENT_ID = "..."
DISCORD_GUILD_ID = "..."
DISCORD_OAB_ROLE_ID = "..."
ADMIN_IDS = "id1,id2"
```

**Dados secretos:** na Cloudflare, abra o Worker → **Settings → Variables and Secrets → Add** e crie, como **Secret**:

- `DISCORD_CLIENT_SECRET` = o Client Secret do Discord
- `SESSION_SECRET` = uma sequência aleatória longa (30+ caracteres, sem espaços)

Nunca coloque esses dois no GitHub. O commit no GitHub republica o site automaticamente.

## 6. Primeiros passos no site

1. Abra o endereço do site e clique em **Entrar com Discord** (entre com um ID que esteja em `ADMIN_IDS`).
2. Vá em **Administração**:
   - **Cadastrar ministros** (nome, tipo Jogador ou NPC, e o ID do Discord se for jogador). Marque quem é o presidente.
   - Crie **advogados temporários** (para partes sem advogado) e informe o número da OAB-RP de cada perfil.
3. Advogados reais entram pelo Discord: no primeiro acesso, quem tem o cargo de OAB cria o cadastro sozinho. A administração informa o número da OAB depois, no painel.
4. Teste: protocole uma ação, confira o sorteio e o sigilo, e baixe um **Exportar backup**.

## Backup

Em **Administração → Backup → Exportar backup**, baixe o arquivo e guarde-o. Faça isso de vez em quando, principalmente antes de mudanças grandes.

## Se algo der errado

- **"O login com Discord ainda não foi configurado":** falta o `DISCORD_CLIENT_ID` no `wrangler.toml`.
- **O Discord diz "redirect_uri inválido":** o endereço em Redirects precisa ser idêntico, terminando em `/auth/callback`.
- **"Cadastro disponível apenas para quem possui o cargo de OAB":** confira o ID do cargo e se a pessoa realmente o tem.
- **Erro de banco ao abrir páginas:** o `database_id` do `wrangler.toml` está errado ou o `schema.sql` não foi executado.
